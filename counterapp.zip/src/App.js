import React from 'react';
import Counter from './containers/Counter';

function App(){
    return (
      <div>
       <Counter />
      </div>
    );
}


export default App;
